<?php
include('condb.php');   

    
    $Username= $_POST["Username"];
    $Password1= $_POST["Password"];
	$Firstname = $_POST["Firstname"];
	$Lastname = $_POST["Lastname"];
	$Birth_date = $_POST["Birth_date"];
    $age = $_POST["age"];
    $Userlevel = $_POST["Userlevel"];

	//table1
	$sql = "INSERT INTO user ( Username, Password ,Firstname,Lastname,Birth_date,age,Userlevel)
			 VALUES( '$Username', '$Password1', '$Firstname ' , '$Lastname' , '$Birth_date', '$age' , '$Userlevel')";
	$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());

	//table2
	
	//ปิดการเชื่อมต่อ database
	mysqli_close($con);
	//จาวาสคริปแสดงข้อความเมื่อบันทึกเสร็จและกระโดดกลับไปหน้าฟอร์ม
	
	if($result){
	echo "<script type='text/javascript'>";
	echo "alert('Save Succesfuly');";
	echo "window.location = 'staffform.php'; ";
	echo "</script>";
	}
	else{
	echo "<script type='text/javascript'>";
	echo "alert('Error!!');";
	echo "</script>";
}
?>