<!DOCTYPE html>
<html>
<meta http-equiv= Content-Type content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="Bookcategory.css">
</head>
<body>

<div class="topnav">
  <a href="Home.html">Home</a>
    <div class="dropdown">
        <button onclick="myFunction()" class="dropbtn">หมวดหมู่</button>
        <div id="myDropdown" class="dropdown-content">
          <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">
          <a href="../Bookcategory/general.php">เบ็ดเตล็ด ความรู้ทั่วไป</a>
          <a href="../Bookcategory/philosophy.php">ปรัชญา</a>
          <a href="../Bookcategory/Religion.php">ศาสนา</a>
          <a href="../Bookcategory/socialScience.php">สังคมศาสตร์</a>
          <a href="../Bookcategory/linguistics.php">ภาษาศาสตร์</a>
          <a href="../Bookcategory/pureScience.php">วิทยาศาสตร์บริสุทธิ์</a>
          <a href="../Bookcategory/appScience.php">วิทยาศาสตร์ประยุกต์</a>
          <a href="../Bookcategory/arts_entertainment.php">ศิลปและการบันเทิง</a>
          <a href="../Bookcategory/literature.php">วรรณคดี</a>
          <a href="../Bookcategory/history.php">ประวัติศาสตร์</a>
        </div>
      </div>
      <script>
          /* When the user clicks on the button,
          toggle between hiding and showing the dropdown content */
          function myFunction() {
            document.getElementById("myDropdown").classList.toggle("show");
          }
          
          function filterFunction() {
            var input, filter, ul, li, a, i;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            div = document.getElementById("myDropdown");
            a = div.getElementsByTagName("a");
            for (i = 0; i < a.length; i++) {
              txtValue = a[i].textContent || a[i].innerText;
              if (txtValue.toUpperCase().indexOf(filter) > -1) {
                a[i].style.display = "";
              } else {
                a[i].style.display = "none";
              }
            }
          }
          </script>
            <a href="../Bookshelf/Bookshelf.html">ชั้นวางหนังสือ</a>
            <!-- <a href="../Promotion/Promotion.html">โปรโมชั่น</a> -->
            <a href="../php/form_login.php">สำหรับพนักงาน</a>
            </div>
            <br>
              <div class="row">
                  <div class="col-3 menu">
                    <ul>
                      <li><a href="../Bookcategory/general.php">เบ็ดเตล็ด ความรู้ทั่วไป</a></li>
                      <li><a href="../Bookcategory/philosophy.php">ปรัชญา</a></li>
                      <li><a href="../Bookcategory/Religion.php">ศาสนา</a></li>
                      <li><a href="../Bookcategory/socialScience.php">สังคมศาสตร์</a></li>
                      <li><a href="../Bookcategory/linguistics.php">ภาษาศาสตร์</a></li>
                      <li><a href="../Bookcategory/pureScience.php">วิทยาศาสตร์บริสุทธิ์</a></li>
                      <li><a href="../Bookcategory/appScience.php">วิทยาศาสตร์ประยุกต์</a></li>
                      <li><a href="../Bookcategory/arts_entertainment.php">ศิลปและการบันเทิง</a></li>
                      <li><a href="../Bookcategory/literature.php">วรรณคดี</a></li>
                      <li><a href="../Bookcategory/history.php">ประวัติศาสตร์</a></li>
                    </ul>
                  </div>
                  <div class="col-9">
                      <h2><p style="text-align:center;">หนังสือหมวดหมู่ วิทยาศาสตร์บริสุทธิ์ (C2)</p></h2>
                      <?php  
             $connect = mysqli_connect("localhost", "root", "", "cs251");  
             mysqli_query($connect,"SET CHARACTER SET UTF8");
             ?>  
             <!DOCTYPE html>  
            
             <html>  
                  <body>  
                
                            <?php  
                            $query = "SELECT * FROM book WHERE catID='C2'"; 
                            $result = mysqli_query($connect, $query);  
                            while($row = mysqli_fetch_array($result)){ 
                          
                              echo "<br/>";
                              echo "<td>" ."<h1>ชื่อหนังสือ : ". $row['Book_Name'] ."</td>";
                              echo "<br/>";
                              echo "<td>"."ชื่อผู้แต่ง : ".$row['Authur_Name']. "</td>"; 
                              echo "<br/>";
                              echo "<br/>";
                                echo ' 
                                      <tr>  
                                           
                                   
                                                <td>   <img src="data:image/jpeg;base64,'.base64_encode($row['Image'] ).'" height="300" width="200" class="img-thumnail" />  
                                           </td>  
                                      </tr>  
                                 ';  
                            } 
                            ?>  
                      
            
                  

</body>
</html>

</head>
<body>



<html>
<head>

<style>
  
body {
  /* background-image: url("../gn-gift_guide_variable_c.jpg"); */
  background-color: lightblue;
}
</style>
</head>
<body>

</body>
</html>
