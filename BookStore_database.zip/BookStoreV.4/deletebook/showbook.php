<!DOCTYPE html>
<html>
<meta http-equiv= Content-Type content="text/html; charset=utf-8">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .login-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
  width:120px;
}

.topnav .login-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background-color: #555;
  color: white;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .login-container button:hover {
  background-color: green;
}

@media screen and (max-width: 600px) {
  .topnav .login-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .login-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>

<div class="topnav">
  <a href="../php/admin_page.php">หน้าหลัก</a> 
  <a href="../insertBook/insert.html">เพิ่มหนังสือ</a>
  <a href="../deletebook/showbook.php">ลบ</a>
  <a href="../Bookshelf/Bookshelf.html">เพิ่มโปรโมชั่น</a>
  <a href="../Employee/Publisher/formpublisher.php">สำนักพิมพ์</a>
  <a href="../staff/staffform.php">เพิ่มพนักงาน</a>
  <a href="../php/logout.php">ออก</a>
  <a href="../php/logout.php">Log out</strong></a>
</div>
</html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
}

* {
  box-sizing: border-box;
}

form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>
</form>

<meta charset="UTF-8">
<?php
//1. เชื่อมต่อ database: 
include('connection.php');  //ไฟล์เชื่อมต่อกับ database ที่เราได้สร้างไว้ก่อนหน้าน้ี

//2. query ข้อมูลจากตาราง: 
$query = "SELECT * FROM book ORDER BY Book_ID asc" or die("Error:" . mysqli_error()); 
//3. execute the query. 
$result = mysqli_query($con, $query); 
//4 . แสดงข้อมูลที่ query ออกมา: 

//ใช้ตารางในการจัดข้อมูล
echo "<table border='1' align='center' width='500'>";
//หัวข้อตาราง
echo "<tr align='center' bgcolor='#CCCCCC'><td>รหัสหนังสือ</td><td>ชื่อหนังสือ</td><td>ผู้แต่ง</td><td>ราคา</td><td>รหัสสำนักพิมพ์
</td><td>รหัสหมวดหมู่</td><td>แก้ไข</td><td>ลบ</td></tr>";
while($row = mysqli_fetch_array($result)) { 
  echo "<tr>";
  echo "<td>" .$row["Book_ID"] .  "</td> "; 
  echo "<td>" .$row["Book_Name"] .  "</td> ";  
  echo "<td>" .$row["Authur_Name"] .  "</td> ";
  echo "<td>" .$row["Price"] .  "</td> ";
  echo "<td>" .$row["ID_Pub"] .  "</td> ";
  
  echo "<td>" .$row["catID"] .  "</td> ";
  //แก้ไขข้อมูลส่่ง member_id ที่จะแก้ไขไปที่ฟอร์ม

  echo "<td><a href='bookdateform.php?Book_ID=$row[0]'>edit</a></td> ";
  
  //ลบข้อมูล
  echo "<td><a href='deletebook.php?Book_ID=$row[0]' onclick=\"return confirm('Do you want to delete this record? !!!')\">del</a></td> ";
  echo "</tr>";
}
echo "</table>";
//5. close connection
mysqli_close($con);
?>