<meta charset="UTF-8">
<?php
//1. เชื่อมต่อ database: 
include('connection.php');  //ไฟล์เชื่อมต่อกับ database ที่เราได้สร้างไว้ก่อนหน้าน้ี

//สร้างตัวแปรสำหรับรับค่าที่นำมาแก้ไขจากฟอร์ม
	$Book_ID = $_REQUEST["Book_ID"];
	$Book_Name = $_REQUEST["Book_Name"];
	$Authur_Name = $_REQUEST["Authur_Name"];
	$Price = $_REQUEST["Price"];
	$ID_Pub= $_REQUEST["ID_Pub"];	
	$catID = $_REQUEST["catID"];

//ทำการปรับปรุงข้อมูลที่จะแก้ไขลงใน database 
	
	$sql = "UPDATE book SET  
			Book_ID='$Book_ID' ,
			Book_Name='$Book_Name' , 
			Authur_Name='$Authur_Name' ,
			Price='$Price' ,
            ID_Pub='$ID_Pub' ,
			catID ='$catID '  
			WHERE Book_ID='$Book_ID' ";

$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());

mysqli_close($con); //ปิดการเชื่อมต่อ database 

//จาวาสคริปแสดงข้อความเมื่อบันทึกเสร็จและกระโดดกลับไปหน้าฟอร์ม
	
	if($result){
	echo "<script type='text/javascript'>";
	echo "alert('Update Succesfuly');";
	echo "window.location = 'showbook.php'; ";
	echo "</script>";
	}
	else{
	echo "<script type='text/javascript'>";
	echo "alert('Error back to Update again');";
	echo "</script>";
}
?>