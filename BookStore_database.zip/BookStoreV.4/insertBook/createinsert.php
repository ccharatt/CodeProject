<?php


$servername = "localhost";
$username ="root";
$password ="";
$dbname = "cs251";

$conn = new mysqli($servername,$username,$password,$dbname);

if($conn -> connect_error){
	die("Connection failed: " .$conn -> connect_error);
}
echo "Connected successfully"."<br>";

// $sql = "CREATE DATABASE cs251";
// if($conn ->query($sql)===TRUE){
// 	echo "Database created successfully"."<br>";
// }else{
// 	echo "Error creating database: ". $conn->error."<br>";
// }


$sql = "CREATE TABLE book (
`Book_ID` int(8) NOT NULL auto_increment,
  `Book_Name` varchar(30) NOT NULL,
  `Authur_Name` varchar(50) NOT NULL,
  `Price` varchar(20) NOT NULL,
  `Image` BLOB NOT NULL, 
  `ID_Pub` varchar(8) NOT NULL, 
  `catID` varchar(5) NOT NULL,
  PRIMARY KEY  (`Book_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

if($conn ->query($sql)===TRUE){
	echo "Table MyGuests created successfully"."<br>";
}else{
	echo "Error creating table: ". $conn->error."<br>";
}

$sql = "INSERT INTO MyGuests (firstname,lastname,email)
VALUES ('John','Doe','john@example.com'), ";
if($conn ->query($sql)===TRUE){
	echo "New record created successfully"."<br>";
}else{
	echo "Error: " .$sql . "<br>". $conn->error."<br>";
}
