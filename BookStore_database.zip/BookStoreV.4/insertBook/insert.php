<?php

include 'insert.html';
if(isset($_POST['insert'])){
     
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="cs251"; // Database name 

// Connect to server and select database.
$connect = mysqli_connect($host, $username, $password, $db_name);
mysqli_set_charset($conn, "utf8");

//data form html
$name=$_POST['name'];
$category=$_POST['cars'];
$authur=$_POST['authur'];
$price=$_POST['price'];
$picture=$_POST['pic'];
$pubid=$_POST['pubid'];

// Insert data into mysql 
$sql="INSERT INTO `book`(`Book_ID`, `Book_Name`, `Authur_Name`, `Price`, `Image`, `ID_Pub`, `catID`) VALUES ('','$name','$authur','$price','$picture',$pubid,'$category')";
$result = mysqli_query($connect,$sql);

//warning
// if($result){
//     echo 'Insert Succeed';
// }else {
//     echo 'Invalid Insert';
// }
//     mysqli_free_result($result);
//     mysqli_close($connect);
}
?> 
