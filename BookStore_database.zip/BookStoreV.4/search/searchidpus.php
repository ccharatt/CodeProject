<!DOCTYPE html>
<html>
<meta charset="utf-8">
<meta http-equiv= Content-Type content="text/html; charset=utf-8">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}
div.c {
  position: absolute;
  right: 300px;  
  top:40%;
    left:50%;
  /* width: 500px;
  height: 520px;
  border: 3px solid green; */
} 


body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .login-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
  width:120px;
}

.topnav .login-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background-color: #555;
  color: white;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .login-container button:hover {
  background-color: green;
}

@media screen and (max-width: 600px) {
  .topnav .login-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .login-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>

<div class="topnav">
  <a class="" href="../Home/Home.html">Home</a>
  <a href="../Bookcategory/ฺBookCategory.html">หมวดหมู่</a>
  <a href="../Bookshelf/Bookshelf.html">ชั้นวางหนังสือ</a>
  <a href="../Promotion/Promotion.html">โปรโมชั่น</a>
</div>

</body>
</html>

<html>
<head>
<style>
  
body {
  /* background-image: url("../gn-gift_guide_variable_c.jpg"); */
  background-color: lightblue;
}
</style>
</head>
<body>

</body>
</html>

<!-- ------------------------------------------------------------------------ -->
<table>

</table>
<?php

$servername = "localhost";
$username ="root";
$password ="";
$dbname = "cs251";

$conn = new mysqli($servername,$username,$password,$dbname);

$set=$_POST['search'];

if($set){
// $show=" SELECT * FROM book where Authur_Name OR Price OR Book_ID ='$set'";
$show = "SELECT book.*,publisher.* FROM book,publisher WHERE book.ID_Pub = publisher.Pub_ID ";
$result = mysqli_query($conn,$show);

    while($rows=mysqli_fetch_array($result)){
    echo "<tr>";
    echo "<td>";
    echo "<br>";
    echo "<center>";
    echo "<th>รหัสหนังสือ :</th> ";
    echo  $rows['Book_ID'];
    echo "</td>";
   
    echo "<tr>";
    echo "<td>";
    echo "<br>";
    echo "<center>";
    echo "<th>ชื่อหนังสือ :</th> ";
    echo  $rows['Book_Name'];
    echo "</td>";

    echo "<tr>";
    echo "<td>";
    echo "<br>";
    echo "<center>";
    echo "<th>ผู้แต่ง :</th> ";
    echo  $rows['Authur_Name'];
    echo "</td>";

    echo "<tr>";
    echo "<td>";
    echo "<br>";
    echo "<center>";
    echo "<th>ราคา : </th> ";
    echo  $rows['Price'];
    echo "</td>";
    echo "<br/>";

    echo "<tr>";
    echo "<td>";
    echo "<br>";
    echo "<center>";
    echo "<th>รหัสหนังสือ: </th> ";
    echo  $rows['Pub_ID'];
    echo "</td>";
    echo "<br/>";

    echo "<td>";?> <img src="<?php echo $row["image"]; ?>" height = "300" width ="400"> <?php echo "</td>";
    }
  
}
else{
    echo "no found";
}
?>
</table>