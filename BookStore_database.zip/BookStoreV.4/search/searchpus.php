<!DOCTYPE html>
<html>
<meta http-equiv= Content-Type content="text/html; charset=utf-8">

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Sarabun" rel="stylesheet">
<style>
* {box-sizing: border-box;}
  
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-image: url("../chibookhero_0.jpg");
  height: 100%;
}
color {
  color : rgb(240, 108, 108);
}
#link_bar a:hover { 
  color:#979393; 
}
g.textsmall{
  font-size: 8px;
}
p.small {
  line-height: 0.5;
}
.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  
  color: rgb(0, 0, 0);
}

.topnav .login-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
  width:120px;
}

.topnav .login-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background-color: #555;
  color: white;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .login-container button:hover {
  background-color: green;
}

@media screen and (max-width: 600px) {
  .topnav .login-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .login-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 17px;    
  border: none;
  outline: none;
  color: rgb(0, 0, 0);
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
  background-color: #ddd;
  color: black;
}

.dropdown:hover .dropdown-content {
  display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
.show {display: block;}

.row::after {
  content: "";
  clear: both;
  display: table;
}

[class*="col-"] {
  float: left;
  padding: 15px;
}

.col-1 {width: 8.33%;}
.col-2 {width: 16.66%;}
.col-3 {width: 25%;}
.col-4 {width: 33.33%;}
.col-5 {width: 41.66%;}
.col-6 {width: 50%;}
.col-7 {width: 58.33%;}
.col-8 {width: 66.66%;}
.col-9 {width: 75%;}
.col-10 {width: 83.33%;}
.col-11 {width: 91.66%;}
.col-12 {width: 100%;}

html {
  font-family: "Lucida Sans", sans-serif;
}

.header {
    background-color: #063149;
  color: #ffffff;
  padding: 15px;
}

.menu ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

.menu li {
  padding: 8px;
  margin-bottom: 7px;
  background-color: #33b6e500;
  color: #ffffff;
  box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
}

.menu li:hover {
  background-color: #ffffff;
}
h2 {
  font-size: 40px;    
    text-align: center;
    color: #000000;
    text-shadow: -1px 0 rgb(255, 255, 255), 0 1px rgb(255, 255, 255),
      4px 0 rgb(255, 255, 255), 0 -1px rgb(255, 255, 255)
    }
    p.sansserif {
      font-size: 20px; 
      font-family: 'Sarabun', sans-serif;
  text-align: center;
    color: #000000;
    line-height: 18pt ;
    text-shadow: -1px -1px white, 1px 1px #333
}
#example1 {
  
  padding: 5px;
  color: #ffffff;
  text-align: center;
  background: rgba(3, 53, 56, 0.658);
  text-shadow: -1px -1px rgb(0, 0, 0);
  background-clip: border-box;  
  width: 500px;
  height: 80px;
  position:absolute; left:430px; top:170px;
}
</style>
</head>
<body>

<div class="topnav">
  <a href="../Home/Home.html">Home</a>
    <div class="dropdown">
        <button onclick="myFunction()" class="dropbtn">หมวดหมู่</button>
        <div id="myDropdown" class="dropdown-content">
          <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">
          <a href="../Bookcategory/general.php">เบ็ดเตล็ด ความรู้ทั่วไป</a>
          <a href="../Bookcategory/philosophy.php">ปรัชญา</a>
          <a href="../Bookcategory/Religion.php">ศาสนา</a>
          <a href="../Bookcategory/socialScience.php">สังคมศาสตร์</a>
          <a href="../Bookcategory/linguistics.php">ภาษาศาสตร์</a>
          <a href="../Bookcategory/pureScience.php">วิทยาศาสตร์บริสุทธิ์</a>
          <a href="../Bookcategory/appScience.php">วิทยาศาสตร์ประยุกต์</a>
          <a href="../Bookcategory/arts_entertainment.php">ศิลปและการบันเทิง</a>
          <a href="../Bookcategory/literature.php">วรรณคดี</a>
          <a href="../Bookcategory/history.php">ประวัติศาสตร์</a>
        </div>
      </div>
      <script>
          /* When the user clicks on the button,
          toggle between hiding and showing the dropdown content */
          function myFunction() {
            document.getElementById("myDropdown").classList.toggle("show");
          }
          
          function filterFunction() {
            var input, filter, ul, li, a, i;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            div = document.getElementById("myDropdown");
            a = div.getElementsByTagName("a");
            for (i = 0; i < a.length; i++) {
              txtValue = a[i].textContent || a[i].innerText;
              if (txtValue.toUpperCase().indexOf(filter) > -1) {
                a[i].style.display = "";
              } else {
                a[i].style.display = "none";
              }
            }
          }
          </script>
            <a href="../Bookshelf/Bookshelf.html">ชั้นวางหนังสือ</a>
            <a href="../Promotion/Promotion.html">โปรโมชั่น</a>
            <a href="../php/form_login.php">สำหรับพนักงาน</a>
            </div>

            
              <h2>กรุณากรอกชื่อหนังสือที่ต้องการค้นหา</h2>
              <p class="sansserif">
                  <div id="example1">
              ลูกค้าสามารถค้นหาหนังสือโดยการกรอกในช่องได้<br/> 
              หรือลูกค้าสามารถเลือกหมวดหมู่,ดูแผนผังร้าน,หาโปรโมชั่น<br/> 
              ได้จากแถบเมนูด้านบนได้ครับ/ค่ะ<br/> 
                  </div>
            </p>
            

            </body>
            </html>
            
            <html>
            <head>

                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <style>
                  @import url(https://fonts.googleapis.com/css?family=Open+Sans);

body{
  font-family: 'Open Sans', sans-serif;
}

.search {
  width: 100%;
  position: relative;
  display: flex;
}

.searchTerm {
  width: 100%;
  border: 3px solid #00B4CC;
  border-right: none;
  padding: 5px;
  height: 50px;
  border-radius: 5px 0 0 5px;
  outline: none;
  color: #9DBFAF;
}

.searchTerm:focus{
  color: #00B4CC;
}

.searchButton {
  width: 45px;
  height: 50px;
  border: 1px solid #00B4CC;
  background: #00B4CC;
  text-align: center;
  color: #fff;
  border-radius: 0 5px 5px 0;
  cursor: pointer;
  font-size: 20px;
}

/*Resize the wrap to see the search bar change!*/
.wrap{
  width: 30%;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}
                </style>
                </head>
                <body>
                
                <!-- <h2>Search Button</h2> -->
                
                <!-- <p>Full width:</p>
                <form class="example" action="/action_page.php">
                  <input type="text" placeholder="Search.." name="search">
                  <button type="submit"><i class="fa fa-search"></i></button>
                </form> -->
                
                <!-- <p>Centered inside a form with max-width:</p> --> 
                
                 <form class="example" action="../search/searchidpus.php" method ="post" style="margin:auto;max-width:300px">
                  <div class="wrap">
                      <div class="search">
                         <input type="text" class="searchTerm" placeholder="Search.." name="search">
                         <button type="submit" class="searchButton"> <i class="fa fa-search"></i></button>
                      </div>
                   </div>
                </form>
            <html>
            <head>

            </head>
            <body>
            
            </body>
            </html>