<?php


$servername = "localhost";
$username ="root";
$password ="";
$dbname = "cs251";

$conn = new mysqli($servername,$username,$password,$dbname);

if($conn -> connect_error){
	die("Connection failed: " .$conn -> connect_error);
}
echo "Connected successfully"."<br>";


$db = mysqli_connect("localhost","root","","DbName"); //keep your db name
$sql = "SELECT * FROM book WHERE Book_Name = $Book_Name";
$sth = $db->query($sql);
$result=mysqli_fetch_array($sth);
echo '<img src="data:image/jpeg;base64,'.base64_encode( $result['image'] ).'"/>';
}