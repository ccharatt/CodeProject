<?php
echo "Hello World"."<br>";

$servername = "localhost";
$username ="root";
$password ="";
$dbname = "cs251";

$conn = new mysqli($servername,$username,$password,$dbname);

if($conn -> connect_error){
	die("Connection failed: " .$conn -> connect_error);
}
echo "Connected successfully"."<br>";

// $sql = "CREATE DATABASE LAB2DB";
// if($conn ->query($sql)===TRUE){
// 	echo "Database created successfully"."<br>";
// }else{
// 	echo "Error creating database: ". $conn->error."<br>";
// }


$sql = "CREATE TABLE  publisher(

`Pub_ID` varchar(10) NOT NULL,
  `Pub_Name` varchar(30) NOT NULL,
  `Pub_Phone` varchar(15) NOT NULL,
  `Pub_Location` varchar(50) NOT NULL,
  `Pub_Email` varchar(30) NOT NULL
  -- `Pub_Phone` varchar(10) NOT NULL,
  -- `Pub_Location` varchar(30) NOT NULL,
  -- `Pub_Emali` varchar(30) NOT NULL,
  
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7;

if($conn ->query($sql)===TRUE){
	echo "Table MyGuests created successfully"."<br>";
}else{
	echo "Error creating table: ". $conn->error."<br>";
}

INSERT INTO `user` VALUES (1, 'aaa', '47bce5c74f589f4867dbd57e9ca9f808', 'aaa', 'aaa', 'A');
INSERT INTO `user` VALUES (2, 'bbb', '08f8e0260c64418510cefb2b06eee5cd', 'bbbb', 'bbbb','M');
$conn ->close();
?>