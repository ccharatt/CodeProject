<?php
include('condb.php');   

	$Pub_ID= $_POST["Pub_ID"];
	$Pub_Name = $_POST["Pub_Name"];
	$Pub_Phone = $_POST["Pub_Phone"];
	$Pub_Location = $_POST["Pub_Location"];
	$Pub_Email = $_POST["Pub_Email"];

	//table1
	$sql = "INSERT INTO publisher (Pub_ID, Pub_Name, Pub_Phone,Pub_Location,Pub_Email)
			 VALUES('$Pub_ID', '$Pub_Name', '$Pub_Phone', '$Pub_Location ', '$Pub_Email')";
	$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());

	//table2
	

	//ปิดการเชื่อมต่อ database
	mysqli_close($con);
	//จาวาสคริปแสดงข้อความเมื่อบันทึกเสร็จและกระโดดกลับไปหน้าฟอร์ม
	
	if($result){
	echo "<script type='text/javascript'>";
	echo "alert('Save Succesfuly');";
	echo "window.location = 'formpublisher.php'; ";
	echo "</script>";
	}
	else{
	echo "<script type='text/javascript'>";
	echo "alert('Error!!');";
	echo "</script>";
}
?>