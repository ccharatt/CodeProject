<!DOCTYPE html>
<html>
<meta http-equiv= Content-Type content="text/html; charset=utf-8">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .login-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
  width:120px;
}

.topnav .login-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background-color: #555;
  color: white;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .login-container button:hover {
  background-color: green;
}

@media screen and (max-width: 600px) {
  .topnav .login-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .login-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>

<div class="topnav">

  <a href="../php/admin_page.php">Home</a>
  <a href="../insertBook/insert.html">เพิ่มหนังสือ</a>
  <a href="../deletebook/showbook.php">ลบ</a>
  <!-- <a href="../Bookshelf/Bookshelf.html">เพิ่มโปรโมชั่น</a> -->
  <a href="../Employee/Publisher/formpublisher.php">สำนักพิมพ์</a>
  <a href="../staff/staffform.php">เพิ่มพนักงาน</a>
  <a href="../php/logout.php">ออก</a>
 
</div>
</html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
}

* {
  box-sizing: border-box;
}

form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>
<body>
</form>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title></title>
</head>

<body>
<form id="formRegister" name="formRegister" method="post" action="../Publisher/addpublisher.php">
  <p><br />
    <br />
  </p>
  <table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td height="40" colspan="2" align="center" bgcolor="#D6D5D6"><b>add data</b></td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>

    <tr>
      <td width="117" align="right">รหัสสำนักพิมพ์
        :</td>
      <td width="583"><input name="Pub_ID" type="text" id="Pub_ID" size="30"   required="required"/></td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    
    <tr>
      <td align="right">ชื่อสำนักพิมพ์
        <label> :</label></td>
      <td><input name="Pub_Name" type="text" id="Pub_Name" size="30"   required="required"/></td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>

    <tr>
      <td align="right">เบอร์ติดต่อ
        <label> :</label></td>
      <td><input name="Pub_Phone" type="text" id="Pub_Phone" size="30"   required="required"/></td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>

    <tr>
      <td align="right">ที่ตั้ง
        <label> :</label></td>
      <td><input name="Pub_Location" type="text" id="Pub_Location" size="30"   required="required"/></td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    
    <tr>
      <td align="right">Email
        <label> :</label></td>
      <td><input name="Pub_Email" type="text" id="Pub_Email" size="30"   required="required"/></td>
    </tr>
    <tr>
      <td align="right">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    

      <td>&nbsp;</td>
      <td>&nbsp;
        &nbsp;
        <input type="submit" name="Register" id="Register" value="SAVE" /></td>
    </tr>
  </table>
</form>
</body>
</html>