<!DOCTYPE html>
<html>
  <meta http-equiv= Content-Type content="text/html; charset=utf-8">
  <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="Stylesheet" href="insert.css">
    <style>
      * {box-sizing: border-box;}

    </style>

      <div class="topnav">
        <a href="../insertBook/insert.html">เพิ่มหนังสือ</a>
        <a href="../Promotion/Promotion.html">แก้ไข/อัพเดท</a>
        <a href="../php/logout.php">Log out</strong></a>
          
        </div>
      </div>   
  </head>

    <div id="id01" class="modal">
        <form class="modal-content" action="/action_page.php">
          <div class="container">
            <h1>Add Book</h1>
            <p>Please fill in this form to create book.</p>
            <hr>
            <label for="name"><b>Name</b></label>
            <input type="text" placeholder="name" name="name" required>

            <label for="category"><b>Category </b></label><br></br>
            <select name="cars">
                <option value="volvo">000 เบ็ดเตล็ด ความรู้ทั่วไป</option>
                <option value="saab">100 ปรัชญา</option>
                <option value="fiat">200 ศาสนา</option>
                <option value="audi">300 สังคมศาสตร์</option>
                <option value="volvo">400 ภาษาศาสตร์</option>
                <option value="volvo">500 วิทยาศาสตร์บริสุทธิ์</option>
                <option value="volvo">600 วิทยาศาสตร์ประยุกต์</option>
                <option value="volvo">700 ศิลปและการบันเทิง</option>
                <option value="volvo">800 วรรณคดี</option>
                <option value="volvo">900 ประวัติศาสตร์</option>
            </select>
            <br></br>
      
            <label for="authur"><b>Authur Name</b></label>
            <input type="text" placeholder="authurname" name="authur" required>

            <label for="price"><b>Price</b></label>
            <input type="text" placeholder="0.00" name="price" required>

            <label for="pic"><b>Picture</b></label> <br></br>
            <form action="/action_page.php" method="post" enctype="multipart/form-data">
                <input type="file" name="pic" id="image">
            </form><br></br>

            <div class="clearfix">
              <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
              <button type="submit" class="signupbtn">Add</button>
            </div>
          </div>
        </form>
 

</html>

